[app]
title = EnglishStudy
package.name = englishstudy
package.domain = org.englishstudy
source.dir = .
source.include_exts = py,png,jpg,ttf,json,atlas
version = 1.0

# 修复11：补齐 plyer,jnius；修复1：锁定 python3==3.11 避开 cgi 模块缺失
requirements = python3==3.11,kivy,plyer,jnius
p4a.python_version = 3.11

# 修复2：接受 SDK 许可 + 固定 build-tools 34.0.0 避开 37 许可坑
android.accept_sdk_license = True
android.build_tools_version = 34.0.0

android.permissions = INTERNET
android.api = 33
android.ndk = 25b
android.sdk = 24

android.archs = arm64-v8a
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
warn_on_root = 1
